/**
 * 
 */
/**
 * 
 */
module GalaxySwissBourdin {
	requires java.sql;
	requires java.desktop;
	requires org.junit.jupiter.api;
}